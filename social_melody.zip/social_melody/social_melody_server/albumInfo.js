const albumInfo = [
    {
        'album': 'Dawn FM',
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'songs': [ 'Best Friends',
                'Every Angel Is Terrifying',
                'Gasoline',
                'Less Than Zero',
                'Out Of Time',
                'Sacrifice',
                'Starry Eyes',
                'Take My Breath'
            ],
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
        }
    },
    {
        'album': 'Unforgettable',
        'imgId': 'xGbSWnUOMmVRloch',
        'artist': 'Imran Khan',
        'songs': [ 'Amplifier',
                    'Bewafa',
                ],
        'backgrounds': {
            'dominant': '0b5f7f',
            'secondary': '0e7ca1'
        }
    },
    {
        'album': 'Epidemic Pop',
        'imgId': 'kiJRsTvzLuZSmPYN',
        'artist': 'Epidemic Pop',
        'songs': [ 'Volcano', 'SHOP'],
        'backgrounds': {
            'dominant': '717f77',
            'secondary': '78C9C3'
        }
    },
]

module.exports = albumInfo;