const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const http = require("http");
const server = http.createServer(app);
const io = require("socket.io")(server, {
  cors: {
    origin: "*",
  },
});
const mysql = require("mysql");
const dbsocket = require("socket.io-client").connect(
  "ws://127.0.0.1:5002/chatdb"
);

// Music info's
const musicData = require("./musicData");
const albumInfo = require("./albumInfo");
const songsInfo = require("./songsInfo");
const fs = require("fs");

// server initial setups
const PORT = 5001;
// For windows
// const albumImgPath = __dirname+"\\assets\\music_img\\";
// For Linux
const albumImgPath = __dirname + "/assets/music_img/";
const albumImgList = fs.readdirSync(albumImgPath);

// allSongs.sort(() => Math.random() - 0.5)
// console.log(allSongs);

// Database :Mysql configuration...
const db_info = {
  db_name: "db_melodyusers",
  table: "usersdat",
};

var conn = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "",
  database: db_info.db_name,
});

conn.connect(function (err) {
  if (err) throw err;
});

// Handling CORS
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  // res.header("Access-Control-Allow-Origin", "POST");
  next();
});

// to parse form urlencoded data
app.use(bodyParser.urlencoded({ extended: true }));
// to parse json data
app.use(express.json());

// continue connect with new db.. && implement username check

//socket.io
const loggedIn = [];
const clients = [];
io.of("/chats").on("connection", (socket) => {
  console.log("connected..."); // continue..
  socket.on("join-room", (data) => {
    data = JSON.parse(data);
    socket.join(data.roomId);
    socket.broadcast.to(data.roomId).emit(
      "message",
      JSON.stringify({
        uname: data.uname,
        msg: "joined the group!",
        roomId: data.roomId,
      })
    );

    try {
      const client = clients.find((client) => client.roomId === data.roomId);
      newData = {
        roomId: client.roomId,
        roomName: client.roomName,
      };
      socket.emit("join-request-acknowledged", JSON.stringify(newData));
    } catch (err) {
      socket.emit(
        "error-occured",
        JSON.stringify({
          error: `Room with id '${data.roomId}' doesn't exists.`,
        })
      );
    }
  }); /// continue

  socket.on("create-room", (data) => {
    data = JSON.parse(data);
    data = {
      roomId: data.roomId,
      roomName: data.roomName,
    };
    clients.push(data);
    socket.join(data.roomId);
    socket.emit("create-request-acknowledged", JSON.stringify(data));
  });

  socket.on("re-join", (data) => {
    data = JSON.parse(data);
    const isThere = clients.find((client) => client.roomId === data.roomId);
    if (typeof isThere === "undefined") clients.push(data);
    if (!loggedIn.includes(data.uname)) loggedIn.push(data.uname);
    socket.join(data.roomId);
  });

  socket.on("loggedin-username", (data) => {
    data = JSON.parse(data);
    if (!loggedIn.includes(data.username)) loggedIn.push(data.username);
  });

  socket.on("message", (data) => {
    data = JSON.parse(data);
    socket.broadcast.to(data.roomId).emit("message", JSON.stringify(data)); // continue
  });

  socket.on("leaving", (data) => {
    data = JSON.parse(data);
    socket.broadcast.to(data.roomId).emit("left", JSON.stringify(data));
    socket.leave(data.roomId);
    // socket.disconnect();
  });

  socket.on("user-typing", async (data)=> {
    data = JSON.parse(data);
    socket.broadcast.to(data.roomId).emit("user-typing", JSON.stringify(data));
  });
  
  socket.on("stopped-typing", async(data)=> {
    data = JSON.parse(data);
    socket.broadcast.to(data.roomId).emit("stopped-typing", JSON.stringify(data));
  });

  // socket.on("reconnecting", (data)=>{
  //     data = JSON.parse(data);
  //     socket.join(data.id);
  // });


  // song play
  socket.on('play-song', (data)=> {
    data = JSON.parse(data);
    const imgId = data.imgId;
    const name = data.name;
    let song = songsInfo.find(
      (song) => song.song === name && song.imgId === imgId
    );
    let musicFiles = fs.readdirSync(__dirname + "\\" + song.path);
    let file = musicFiles.find((file) => file.includes(name));
    let fData = fs.readFileSync(__dirname + "\\" + song.path + "\\" + file);
    b64Data = Buffer.from(fData).toString("base64");
    const respData = JSON.stringify([
      {
        album: song.song,
        artist: song.artist,
        imgId: song.imgId,
        currentAlbumIdx: 0,
        songs: [],
      },
      {
        source: b64Data,
      },
    ]);
    socket.emit('play-song', respData);
  });


  socket.on('play-album', (data)=> {
    data = JSON.parse(data);
    const imgId = data.imgId;
    const music = musicData.find((element) => element.imgId === imgId);
    const musicDir = __dirname + "\\" + music.path;
    const files = fs.readdirSync(musicDir);
    const file = files[0];
    const fData = fs.readFileSync(musicDir + "\\" + file);
    const indexOfMusicFromMusicInfo = albumInfo.indexOf(
      albumInfo.find((elem) => elem.imgId === imgId)
    );
    const song = songsInfo.find((song) => file.includes(song.song));
    b64Data = Buffer.from(fData).toString("base64");
    const respData = JSON.stringify([
      {
        album: song.song,
        artist: song.artist,
        imgId: song.imgId,
        albumImgId: imgId,
        currentAlbumIdx: 0,
        songs: albumInfo[indexOfMusicFromMusicInfo].songs,
      },
      {
        source: b64Data,
      },
    ]);
    socket.emit('play-song', respData);
  });


  socket.on('nextSong', (data)=> {
    data = JSON.parse(data);
    let imgId = data.imgId;
    const index  = (data.currentIdx)+1;
    try {
      const music = musicData.find((element) => element.imgId === imgId);
      const musicDir = __dirname + "\\" + music.path;
      const files = fs.readdirSync(musicDir);
      let indexOfMusicFromMusicInfo = albumInfo.indexOf(albumInfo.find((elem) => elem.imgId === imgId));
      console.log(indexOfMusicFromMusicInfo);
      if (index + 1 > albumInfo[indexOfMusicFromMusicInfo].songs.length) {
        // checking if more songs are there in current album.
        const elem = musicData.find((elem) => imgId === elem.imgId);
        const elemIdx = musicData.indexOf(elem);
        if (elemIdx + 2 > musicData.length) {
          // if no more album preset
          socket.emit('switch-song', JSON.stringify("reset"));
        } else {
          imgId = musicData[elemIdx + 1].imgId;
          album = musicData[elemIdx + 1].album;
          artist = musicData[elemIdx + 1].artist;
          const path = musicData[elemIdx + 1].path;
          const musicDir = __dirname + "\\" + path;
          const files = fs.readdirSync(musicDir);
          const file = files[0];
          const fData = fs.readFileSync(musicDir + "\\" + file);
          const song = songsInfo.find((song) => file.includes(song.song));
          b64Data = Buffer.from(fData).toString("base64");
          indexOfMusicFromMusicInfo = albumInfo.indexOf(
            albumInfo.find((elem) => elem.imgId === imgId)
          );
          const respData = JSON.stringify([
            {
              album: song.song,
              artist: song.artist,
              imgId: song.imgId,
              albumImgId: imgId,
              currentAlbumIdx: 0,
              songs: albumInfo[indexOfMusicFromMusicInfo].songs,
            },
            {
              action: data.action,
              source: b64Data,
            },
          ]);
          socket.emit('switch-song', respData);
        }
      } else {
        const file = files[index];
        const fData = fs.readFileSync(musicDir + "\\" + file);
        // console.log(musicDir+'\\'+file);
        const song = songsInfo.find((song) => file.includes(song.song));
        b64Data = Buffer.from(fData).toString("base64");
        const respData = JSON.stringify([
          {
            album: song.song,
            artist: song.artist,
            imgId: song.imgId,
            currentAlbumIdx: index,
            albumImgId: imgId,
            songs: albumInfo[indexOfMusicFromMusicInfo].songs,
            // backgrounds: albumInfo[indexOfMusicFromMusicInfo].backgrounds
          },
          {
            action: data.action,
            source: b64Data,
          },
        ]);
        socket.emit('switch-song', respData);
      }
    } catch (err) {
      socket.emit('switch-song', JSON.stringify("reset"));
    }
  });

  socket.on('prevSong', (data)=> {
    data = JSON.parse(data);
    let imgId = data.imgId;
    const index = (data.currentIdx) - 1;
    try{
      const music = musicData.find((element) => element.imgId === imgId);
      const musicDir = __dirname + "\\" + music.path;
      const files = fs.readdirSync(musicDir);
      let indexOfMusicFromMusicInfo = albumInfo.indexOf(
        albumInfo.find((elem) => elem.imgId === imgId)
      );
      if (index < 0) {
        const elem = musicData.find((elem) => imgId === elem.imgId);
        const elemIdx = musicData.indexOf(elem);
        if (elemIdx < 0) {
          socket.emit('switch-song', JSON.stringify("reset"));
        } else {
          imgId = musicData[elemIdx - 1].imgId;
          album = musicData[elemIdx - 1].album;
          artist = musicData[elemIdx - 1].artist;
          const path = musicData[elemIdx - 1].path;
          const musicDir = __dirname + "\\" + path;
          const files = fs.readdirSync(musicDir);
          const file = files[0];
          const fData = fs.readFileSync(musicDir + "\\" + file);
          indexOfMusicFromMusicInfo = albumInfo.indexOf(
            albumInfo.find((elem) => elem.imgId === imgId)
          );
          const song = songsInfo.find((song) => file.includes(song.song));
          b64Data = Buffer.from(fData).toString("base64");
          const respData = JSON.stringify([
            {
              album: song.song,
              artist: song.artist,
              imgId: song.imgId,
              albumImgId: imgId,
              currentAlbumIdx:
                albumInfo[indexOfMusicFromMusicInfo].songs.length - 1,
              songs: albumInfo[indexOfMusicFromMusicInfo].songs,
            },
            {
              action: data.action,
              source: b64Data,
            },
          ]);
          socket.emit('switch-song', respData);
        }
      } else {
        const file = files[index];
        const fData = fs.readFileSync(musicDir + "\\" + file);
        // console.log(musicDir+'\\'+file);
        const song = songsInfo.find((song) => file.includes(song.song));
        b64Data = Buffer.from(fData).toString("base64");
        const respData = JSON.stringify([
          {
            album: song.song,
            artist: song.artist,
            imgId: song.imgId,
            albumImgId: imgId,
            currentAlbumIdx: index,
            songs: albumInfo[indexOfMusicFromMusicInfo].songs,
          },
          {
            action: data.action,
            source: b64Data,
          },
        ]);
        socket.emit('switch-song', respData);
      }
    } catch(err) {
      socket.emit('switch-song', JSON.stringify("reset"));
    }
  });


  socket.on('next-song-broadcast', (data)=> {
    data = JSON.parse(data);
    socket.broadcast.to(data.roomId).emit('next-song-broadcast', JSON.stringify(data));
  })


  // For handling audio player synchroniztion...
  socket.on("song-broadcast", (data) => {
    data = JSON.parse(data);
    socket.broadcast
      .to(data.roomId)
      .emit("song-broadcast", JSON.stringify(data));
  });

  socket.on("toggle-loop", (data) => {
    data = JSON.parse(data);
    socket.broadcast.to(data.roomId).emit("toggle-loop", JSON.stringify(data));
  });

  socket.on("active-music-status", (data) => {
    data = JSON.parse(data);
    socket.broadcast
      .to(data.roomId)
      .emit("active-music-status", JSON.stringify(data));
  });

  socket.on("switch-song-broadcast", (data) => {
    data = JSON.parse(data);
    socket.broadcast
      .to(data.roomId)
      .emit("switch-song-broadcast", JSON.stringify(data));
  });

  socket.on("play-pause", (data) => {
    data = JSON.parse(data);
    socket.broadcast
      .to(data.roomId)
      .emit("play-pause-broadcast", JSON.stringify(data));
  });

  socket.on("seek-bar-change-broadcast", (data) => {
    data = JSON.parse(data);
    socket.broadcast
      .to(data.roomId)
      .emit("seek-bar-change-broadcast", JSON.stringify(data));
  });

  socket.on("seek-bar-change-broadcast", (data) => {
    data = JSON.parse(data);
    socket.broadcast
      .to(data.roomId)
      .emit("seek-bar-change-broadcast", JSON.stringify(data));
  });

  // Handling Chat Database
  socket.on("insertNewRec", async (payload) => {
    dbsocket.emit("insertNewRec", payload);
  });

  socket.on("insertMsg", async (payload) => {
    dbsocket.emit("insertMsg", payload);
  });

  socket.on("insertRecvMsg", async (payload) => {
    dbsocket.emit("insertRecvMsg", payload);
  });

  socket.on("insertRoom", async (payload) => {
    dbsocket.emit("insertRoom", payload);
  });

  socket.on("leaving-room", async (payload) => {
    dbsocket.emit("leaving-room", payload);
  });

  // add check for distinct username ....
  socket.on("fetch", async (payload) => {
    dbsocket.emit("fetch", payload);
  });

  dbsocket.off("fetch-result").on("fetch-result", (data) => {
    socket.emit("fetch-result", data);
  });
});

// api endpoints
app.get("/", (req, res) => {
  res.json({
    status: "works",
  });
});

// get album img
app.get("/getImg", (req, res) => {
  const imgId = albumImgList.find((id) => id === req.query.imgId);
  imgId ? res.sendFile(albumImgPath + imgId) : res.sendStatus(404);
});

app.post("/all_songs", (req, res) => {
  let tempSongs = JSON.parse(JSON.stringify(songsInfo));
  tempSongs.forEach( item =>{
    delete item['path'];
  });
  tempSongs.sort(() => Math.random() - 0.5);
  res.json({
    albumInfo: albumInfo,
    allSongs: tempSongs,
  });
});

app.post("/getAlbum", (req, res) => {
  let albumName = req.body.album;
  let tempAlbum = albumInfo;
  tempAlbum.sort(() => Math.random() - 0.5);
  tempAlbum = tempAlbum.slice(0, 3);
  let albumData = albumInfo.find((album) => album.album === albumName);
  res.json({
    albumData: albumData,
    otherAlbums: tempAlbum,
  });
});

app.post("/nextSong", (req, res) => {
  try {
    const index = parseInt(req.query.idx) + 1; // going for next index.
    let imgId = req.query.imgId;
    const music = musicData.find((element) => element.imgId === imgId);
    const musicDir = __dirname + "\\" + music.path;
    const files = fs.readdirSync(musicDir);
    let indexOfMusicFromMusicInfo = albumInfo.indexOf(albumInfo.find((elem) => elem.imgId === imgId));
    console.log(indexOfMusicFromMusicInfo);
    if (index + 1 > albumInfo[indexOfMusicFromMusicInfo].songs.length) {
      // checking if more songs are there in current album.
      const elem = musicData.find((elem) => imgId === elem.imgId);
      const elemIdx = musicData.indexOf(elem);
      if (elemIdx + 2 > musicData.length) {
        // if no more album preset
        res.send("reset");
      } else {
        imgId = musicData[elemIdx + 1].imgId;
        album = musicData[elemIdx + 1].album;
        artist = musicData[elemIdx + 1].artist;
        const path = musicData[elemIdx + 1].path;
        const musicDir = __dirname + "\\" + path;
        const files = fs.readdirSync(musicDir);
        const file = files[0];
        const fData = fs.readFileSync(musicDir + "\\" + file);
        const song = songsInfo.find((song) => file.includes(song.song));
        b64Data = Buffer.from(fData).toString("base64");
        indexOfMusicFromMusicInfo = albumInfo.indexOf(
          albumInfo.find((elem) => elem.imgId === imgId)
        );
        res.json([
          {
            album: song.song,
            artist: song.artist,
            imgId: song.imgId,
            albumImgId: imgId,
            currentAlbumIdx: 0,
            songs: albumInfo[indexOfMusicFromMusicInfo].songs,
          },
          {
            source: b64Data,
          },
        ]);
      }
    } else {
      const file = files[index];
      const fData = fs.readFileSync(musicDir + "\\" + file);
      // console.log(musicDir+'\\'+file);
      const song = songsInfo.find((song) => file.includes(song.song));
      b64Data = Buffer.from(fData).toString("base64");
      res.json([
        {
          album: song.song,
          artist: song.artist,
          imgId: song.imgId,
          currentAlbumIdx: index,
          albumImgId: imgId,
          songs: albumInfo[indexOfMusicFromMusicInfo].songs,
          // backgrounds: albumInfo[indexOfMusicFromMusicInfo].backgrounds
        },
        {
          source: b64Data,
        },
      ]);
    }
  } catch (err) {}
});

app.post("/getSong", (req, res) => {
  const imgId = req.query.imgId;
  const music = musicData.find((element) => element.imgId === imgId);
  const musicDir = __dirname + "\\" + music.path;
  const files = fs.readdirSync(musicDir);
  const file = files[0];
  const fData = fs.readFileSync(musicDir + "\\" + file);
  const indexOfMusicFromMusicInfo = albumInfo.indexOf(
    albumInfo.find((elem) => elem.imgId === imgId)
  );
  const song = songsInfo.find((song) => file.includes(song.song));
  b64Data = Buffer.from(fData).toString("base64");
  res.json([
    {
      album: song.song,
      artist: song.artist,
      imgId: song.imgId,
      albumImgId: imgId,
      currentAlbumIdx: 0,
      songs: albumInfo[indexOfMusicFromMusicInfo].songs,
    },
    {
      source: b64Data,
    },
  ]);
});

app.post("/prevSong", (req, res) => {
  const index = parseInt(req.query.idx) - 1; // going for prev index.
  let imgId = req.query.imgId;
  const music = musicData.find((element) => element.imgId === imgId);
  const musicDir = __dirname + "\\" + music.path;
  const files = fs.readdirSync(musicDir);
  let indexOfMusicFromMusicInfo = albumInfo.indexOf(
    albumInfo.find((elem) => elem.imgId === imgId)
  );
  if (index < 0) {
    const elem = musicData.find((elem) => imgId === elem.imgId);
    const elemIdx = musicData.indexOf(elem);
    if (elemIdx < 0) {
      res.send("reset");
    } else {
      imgId = musicData[elemIdx - 1].imgId;
      album = musicData[elemIdx - 1].album;
      artist = musicData[elemIdx - 1].artist;
      const path = musicData[elemIdx - 1].path;
      const musicDir = __dirname + "\\" + path;
      const files = fs.readdirSync(musicDir);
      const file = files[0];
      const fData = fs.readFileSync(musicDir + "\\" + file);
      indexOfMusicFromMusicInfo = albumInfo.indexOf(
        albumInfo.find((elem) => elem.imgId === imgId)
      );
      const song = songsInfo.find((song) => file.includes(song.song));
      b64Data = Buffer.from(fData).toString("base64");
      res.json([
        {
          album: song.song,
          artist: song.artist,
          imgId: song.imgId,
          albumImgId: imgId,
          currentAlbumIdx:
            albumInfo[indexOfMusicFromMusicInfo].songs.length - 1,
          songs: albumInfo[indexOfMusicFromMusicInfo].songs,
        },
        {
          source: b64Data,
        },
      ]);
    }
  } else {
    const file = files[index];
    const fData = fs.readFileSync(musicDir + "\\" + file);
    // console.log(musicDir+'\\'+file);
    const song = songsInfo.find((song) => file.includes(song.song));
    b64Data = Buffer.from(fData).toString("base64");
    res.json([
      {
        album: song.song,
        artist: song.artist,
        imgId: song.imgId,
        albumImgId: imgId,
        currentAlbumIdx: index,
        songs: albumInfo[indexOfMusicFromMusicInfo].songs,
      },
      {
        source: b64Data,
      },
    ]);
  }
});

app.post("/albumPlay", (req, res) => {
  const index = req.query.idx;
  const imgId = req.query.imgId;
  const music = musicData.find((data) => data.imgId === imgId);
  const albumDir = __dirname + "\\" + music.path;
  const files = fs.readdirSync(albumDir);
  const file = files[index];
  const fData = fs.readFileSync(albumDir + "\\" + file);
  let indexOfMusicFromMusicInfo = albumInfo.indexOf(
    albumInfo.find((elem) => elem.imgId === imgId)
  );
  b64Data = Buffer.from(fData).toString("base64");
  res.json([
    {
      album: music.album,
      artist: music.artist,
      imgId: music.imgId,
      currentAlbumIdx: index,
      songs: albumInfo[indexOfMusicFromMusicInfo].songs,
    },
    {
      source: b64Data,
    },
  ]);
});

app.post("/play", (req, res) => {
  const name = req.query.song;
  const imgId = req.query.imgId;
  let song = songsInfo.find(
    (song) => song.song === name && song.imgId === imgId
  );
  let musicFiles = fs.readdirSync(__dirname + "\\" + song.path);
  let file = musicFiles.find((file) => file.includes(name));
  let fData = fs.readFileSync(__dirname + "\\" + song.path + "\\" + file);
  b64Data = Buffer.from(fData).toString("base64");
  res.json([
    {
      album: song.song,
      artist: song.artist,
      imgId: song.imgId,
      currentAlbumIdx: 0,
      songs: [],
    },
    {
      source: b64Data,
    },
  ]);
});

function checkIfUsernameOrEmailExists() {
  //Todo....
}

// Authentication stuff...
function insert(username, name, email, password, res) {
  // TODO: Add hashing function at end.
  let sql = `INSERT INTO ${db_info.table} (username, name, email, passwd) VALUES (?, ?, ?, ?)`;
  let inserts = [username, name, email, password];
  sql = mysql.format(sql, inserts);
  conn.query(sql, function (err, result) {
    if (err) {
      res.status(200).send({
        message: "Something went bad.",
      });
    } else {
      // If everthing is fine..
      res.status(200).send({
        message: "success",
      });
    }
  });
}

app.post("/login", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  if (loggedIn.includes(username)) {
    res.status(200).send({
      message: "Already logged In.",
    });
    return;
  }
  conn.query(
    `SELECT passwd FROM ${db_info.table} WHERE username="${username}"`,
    (err, resl) => {
      if (err) throw err;
      // If operator id not in database...
      if (resl.length === 0) {
        res.status(200).send({
          message: "Bad username",
        });
        return;
      }

      const passwd = resl[0].passwd;
      // If password doesn't match...
      if (password !== passwd) {
        res.status(200).send({
          message: "Bad Password",
        });
        return;
      }

      // If everything is fine..
      res.status(200).send({
        message: "success",
      });
      loggedIn.push(username);
    }
  );
});

const isUsernameOrEmailAvailable = (username, name, email, password, res) => {
  let sql = `SELECT username, email from ${db_info.table}`;
  conn.query(sql, (err, result) => {
    result = JSON.parse(JSON.stringify(result));
    const udata = result.filter(
      (data) => data.username === username || data.email === email
    );
    if (udata.length > 0) {
      if (udata[0].username === username) {
        res.json({
          message: "username already exists",
        });
      } else if (udata[0].email === email) {
        res.json({
          message: "email already exists",
        });
      }
    } else {
      insert(username, name, email, password, res);
    }
  });
};

app.post("/signup", async (req, res) => {
  const username = req.body.username;
  const name = req.body.name;
  const email = req.body.email;
  const password = req.body.password;
  isUsernameOrEmailAvailable(username, name, email, password, res);
});

app.post("/getdetails", async (req, res) => {
  username = req.query.username;
  console.log(username);
  let sql = `SELECT name, email from ${db_info.table} WHERE username="${username}"`;
  conn.query(sql, (err, result) => {
    if (err) throw err;
    if (result.length > 0) {
      result = JSON.parse(JSON.stringify(result));
      res.json(result[0]);
    } else {
      res.json({
        message: "something went wrong",
      });
    }
  });
});

app.post("/loggedout", (req, res) => {
  const username = req.query.username;
  const index = loggedIn.indexOf(username);
  if (typeof index !== undefined) {
    loggedIn.splice(index, 1);
    res.sendStatus(200);
  } else {
    res.sendStatus(401);
  }
});

server.listen(PORT, () => {
  console.log(`Listening on Port ${PORT}...`);
});
