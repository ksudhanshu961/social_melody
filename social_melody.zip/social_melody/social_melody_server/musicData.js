// Add album image id...
const musicData = [
    {
        'album': 'The Weeknd',
        'artist': 'The Weeknd',
        'imgId': 'sZbPcdHqIrRSUMuT',
        'path': 'assets\\music\\The Weeknd',
    },
    {
        'album': 'Bullet',
        'artist': 'Jassimran Singh Keer',
        'imgId': 'LYzXytIdogDfChQJ',
        'path': 'assets\\music\\Jassimran Singh Keer'
    },
    {
        'album': 'After Dark',
        'artist': 'Mr.Kitty',
        'imgId': 'RPFagYCVzILcZslM',
        'path': 'assets\\music\\Mr Kitty',
    },
    {
        'album': 'Excuses',
        'artist': 'AP Dhillon',
        'imgId': 'NUBYLoibCEGPHxdj',
        'path': 'assets\\music\\AP Dhillon',
    },
    {
        'album': 'Unforgettable',
        'artist': 'Imran Khan',
        'imgId': 'xGbSWnUOMmVRloch',
        'path': 'assets\\music\\Imran Khan',
    },
    {
        'album': 'Epidemic Pop',
        'artist': 'Epidemic Pop',
        'imgId': 'kiJRsTvzLuZSmPYN',
        'path': 'assets\\music\\Epidemic Pop',
    },
    {
        'album': 'Epidemic Pop',
        'artist': 'Epidemic Pop',
        'imgId': 'kiJRsTvzLuZSmPYN',
        'path': 'assets\\music\\Epidemic Pop',
    },
];

module.exports = musicData;