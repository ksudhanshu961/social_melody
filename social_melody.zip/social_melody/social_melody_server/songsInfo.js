const songInfo = [
    {
        'imgId': 'LYzXytIdogDfChQJ',
        'artist': 'Jassimran Singh Keer',
        'song': 'Bullet',
        'path': 'assets\\music\\Jassimran Singh Keer',
        'backgrounds': {
            'dominant': '794c30',
            'secondary': 'd9b792'
        }
    },
    {
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'song': 'Best Friends',
        'path': 'assets\\music\\The Weeknd',
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
           }
    },
    {
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'song': 'Every Angel Is Terrifying',
        'path': 'assets\\music\\The Weeknd',
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
           }
    },
    {
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'song': 'Gasoline',
        'path': 'assets\\music\\The Weeknd',
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
           }
    },
    {
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'song': 'Less Than Zero',
        'path': 'assets\\music\\The Weeknd',
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
           }
    },
    {
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'song': 'Out Of Time',
        'path': 'assets\\music\\The Weeknd',
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
           }
    },
    {
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'song': 'Sacrifice',
        'path': 'assets\\music\\The Weeknd',
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
           }
    },
    {
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'song': 'Starry Eyes',
        'path': 'assets\\music\\The Weeknd',
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
           }
    },
    {
        'imgId': 'sZbPcdHqIrRSUMuT',
        'artist': 'The Weeknd',
        'song': 'Take My Breath',
        'path': 'assets\\music\\The Weeknd',
        'backgrounds': {
            'dominant': '608b99',
            'secondary': '254f5f'
           }
    },
    {
        'imgId': 'RPFagYCVzILcZslM',
        'artist': 'Mr.Kitty',
        'song': 'After Dark',
        'path': 'assets\\music\\Mr Kitty',
        'backgrounds': {
            'dominant': '97272c',
            'secondary': '692022'
        }
    },
    {
        'imgId': 'NUBYLoibCEGPHxdj',
        'artist': 'AP Dhillon',
        'song': 'Excuses',
        'path': 'assets\\music\\AP Dhillon',
        'backgrounds': {
            'dominant': 'dc837a',
            'secondary': '9c2f27'
           }
    },
    {
        'imgId': 'NUBYLoibCEGPHxdj',
        'artist': 'AP Dhillon',
        'song': 'Saada Pyaar',
        'path': 'assets\\music\\AP Dhillon',
        'backgrounds': {
            'dominant': 'dc837a',
            'secondary': '9c2f27'
           }
    },
    {
        'imgId': 'xGbSWnUOMmVRloch',
        'artist': 'Imran Khan',
        'song': 'Amplifier',
        'path': 'assets\\music\\Imran Khan',
        'backgrounds': {
            'dominant': '0b5f7f',
            'secondary': '0e7ca1'
           }
    },
    {
        'imgId': 'xGbSWnUOMmVRloch',
        'artist': 'Imran Khan',
        'song': 'Bewafa',
        'path': 'assets\\music\\Imran Khan',
        'backgrounds': {
            'dominant': '0b5f7f',
            'secondary': '0e7ca1'
           }
    },
    {
        'imgId': 'afOVjurLJzTgYWCA',
        'artist': 'Epidemic Pop',
        'song': 'Volcano',
        'path': 'assets\\music\\Epidemic Pop',
        'backgrounds': {
            'dominant': '717f77',
            'secondary': '78C9C3'
        }
    },
    {
        'imgId': 'fusVnZcRtvWGIFLH',
        'artist': 'Epidemic Pop',
        'song': 'SHOP',
        'path': 'assets\\music\\Epidemic Pop',
        'backgrounds': {
            'dominant': '717f77',
            'secondary': '78C9C3'
        }
    },
]

module.exports = songInfo;