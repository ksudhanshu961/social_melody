const savedChatData = []
const users = {}

module.exports = {
    savedChatData,
    users,
};