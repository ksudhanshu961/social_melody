#!/usr/bin/env node

const { Server } = require("socket.io");

const io = new Server(5002, {
    cors: {
        origin: "*"
    }
});

const fs = require("fs");
const {savedChatData, users} = require("./savedChatData");
const backupChatData = require('./backupChatsData');

//

// const DOMAIN = '127.0.0.1:5001';
// const ENDPOINT = '/chatdb';
let isInserting = false;

// const floatingData = [];

/*
| schem a |
-----------
[
roomId: {
     username: username
     roomName: name,
     messages = [],
    }, ...
]
*/

const saveTheRecord = async() => {
    isInserting = true;
    let data = `const savedChatData = ${JSON.stringify(savedChatData)}
const users = ${JSON.stringify(users)}

module.exports = {
    savedChatData,
    users,
};`
    fs.writeFile(__dirname+'/savedChatData.js', data, 'utf8',(err)=>{
	    if(err) fs.writeFile('errors.log', err, (err)=>{
	        if(err){
		    console.log('Error while writing error log file: \n', err);
		    isInserting = false;
	        }
    	});
        console.log('Record saved!');
	    isInserting = false;
    });
}


const insertMgs = async(payload) => {
    try{
        if(!isInserting){
            payload = JSON.parse(payload);
            const room = savedChatData[users[payload.uname]].rooms.find(room => room.roomId === payload.roomId);
            room.messages.push(payload);
            console.log('Msg Record inserted');
        } else {
            setTimeout(()=>{
                insertMgs(payload);
            }, 5000);
        }
    } catch(err){
        fs.writeFile(__dirname+'\\savedChatData.js', `const savedChatData = ${JSON.stringify(backupChatData)}\n\nmodule.exports = savedChatData;`, 'utf-8', (err)=>{
            if(err) console.log(err);
            insertMgs(payload);
        });
    }
};

const insertRecvMgs = async(payload) => {
    try{
        if(!isInserting){
            payload = JSON.parse(payload);
            const room = savedChatData[users[payload.uname]].rooms.find(room => room.roomId === payload.data.roomId);
            room.messages.push(payload.data);
            console.log('Msg Record inserted');
        } else {
            setTimeout(()=>{
                insertMgs(payload);
            }, 5000);
        }
    } catch(err){
        fs.writeFile(__dirname+'\\savedChatData.js', `const savedChatData = ${JSON.stringify(backupChatData)}\n\nmodule.exports = savedChatData;`, 'utf-8', (err)=>{
            if(err) console.log(err);
            insertRecvMgs(payload);
        });
    }
};


// const getRoomName = (payload, socket) => {
//     if(!isInserting){
//         payload = JSON.parse(payload);
//         const tempData = savedChatData.find(data => data.rooms.find(room => payload.roomId === room.roomId));
//         const roomData = tempData.rooms.find(room => room.roomId === payload.roomId);
//         socket.emit("room-name", JSON.stringify({
//             roomName: roomData.roomName,
//         }));
//     } else {
//         setTimeout(()=>{
//             getRoomName(payload);
//         }, 5000);
//     }
// }


const insertRooms = async(payload) => {
    if(!isInserting){
        payload = JSON.parse(payload);
        // const userdata = savedChatData.find(data => payload.uname === data.username);
        savedChatData[users[payload.uname]].rooms.push(payload.roomData);
        saveTheRecord();
    } else {
        setTimeout(()=>{
            insertRooms(payload);
        }, 5000);
    }
}


const removeRoom = async(payload) => {
    if(!isInserting){
        payload = JSON.parse(payload);
        savedChatData[users[payload.uname]].rooms.splice(payload.idx, 1);
        saveTheRecord();
    } else {
        setTimeout(()=>{
            removeUser(payload);
        }, 5000);
    }
}

// const socket = io.connect(`ws://${DOMAIN}${ENDPOINT}`);
io.of('/chatdb').on('connection', (socket)=>{
    console.log('Connected...');
    
    socket.on('insertNewRec', async(payload)=> {
        payload = JSON.parse(payload);
        // console.log(payload);
        savedChatData.push(payload); 
        users[payload.username] = savedChatData.length - 1;   
        await saveTheRecord();
        fs.writeFile(__dirname+'\\n', '', 'utf-8', (err)=>{
            if(err) throw err;
        });
        // console.log('New Record initialized');
    });
    
    
    
    socket.on('insertMsg', async(payload)=>{
        insertMgs(payload);
        // console.log(JSON.parse(payload));
        saveTheRecord();
    });
    
    socket.on('insertRecvMsg', async(payload)=>{
        insertRecvMgs(payload);
        // console.log(JSON.parse(payload));
        saveTheRecord();
    });
    
    socket.on('insertRoom', async(payload)=>{
        // console.log(payload);
        insertRooms(payload)
        saveTheRecord();
    }); // continue here to add join-room insert 
    
    
    socket.on('leaving-room', async(payload)=>{
        removeRoom(payload);
    });
    
    // add check for distinct username ....
    socket.on('fetch', async(payload)=> {
        payload = JSON.parse(payload);
        const userdata = savedChatData[users[payload.username]]
        socket.emit('fetch-result', JSON.stringify(userdata));
    });
    
    // socket.on('fetch-room-name', (payload)=>{
        //     getRoomName(payload, socket);
        // });
        
    });
    
    
    // Sync with file.
    // setTimeout(()=>{
        //     setInterval(()=>{
            //         saveTheRecord();
            //     }, 60000);
            // }, 3000)
            