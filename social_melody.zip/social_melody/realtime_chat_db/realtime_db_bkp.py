import hashlib
import sys

old_hash = None

def readFile(filename):
    with open(filename, 'r') as reader:
        return reader.read()

def writeFile(data):
    data = data.replace('savedChatData', 'backupChatData')
    with open('backupChatsData.js', 'w') as writer:
        writer.write(data)

def backupSaveChat(data):
        writeFile(data)

def matchTheHash(data):
    global old_hash
    hash = hashlib.md5(data.encode()).hexdigest()
    if old_hash != hash:
        backupSaveChat(data)
        old_hash = hash


if __name__ == '__main__':
    while True:
        try:
            data = readFile('./savedChatData.js')
            if data != '':
                matchTheHash(data)
        except KeyboardInterrupt:
            sys.exit(0)