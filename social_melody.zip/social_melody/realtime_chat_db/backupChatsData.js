const backupChatData = []
const users = {}

module.exports = {
    backupChatData,
    users,
};